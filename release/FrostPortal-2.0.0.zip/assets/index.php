<?php
  /**
   * Tudedude's Frost Portal
   * **
   * This file is simply here to prevent people from viewing an index
   * of files in this directory, for security purposes.
   */
?>